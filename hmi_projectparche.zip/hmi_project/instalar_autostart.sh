#!/bin/bash
# Instala el arranque automático del HMI para el usuario actual.
# Uso (en la Raspberry Pi, dentro de la carpeta del proyecto):
#     chmod +x instalar_autostart.sh && ./instalar_autostart.sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
DESTINO="$HOME/.config/autostart"

chmod +x "$DIR/iniciar_hmi.sh"
mkdir -p "$DESTINO"
sed "s|@DIR@|$DIR|g" "$DIR/hmi-autostart.desktop" > "$DESTINO/hmi-autostart.desktop"

echo "Listo: $DESTINO/hmi-autostart.desktop"
echo "  -> arranca $DIR/iniciar_hmi.sh (log en $HOME/hmi_data/hmi.log)"
echo
echo "Para que abra solo al ENCENDER la Pi, también necesitas (una sola vez):"
echo "  sudo raspi-config -> System Options -> Boot / Auto Login -> Desktop Autologin"
echo "  sudo raspi-config -> Display Options -> Screen Blanking -> No"
if ! id -nG | tr ' ' '\n' | grep -qx dialout; then
    echo "  sudo usermod -aG dialout \$(id -un)     (acceso al puerto serial del Pico; luego reinicia)"
fi
