#!/bin/bash
# Lanzador del HMI METEOR-M (lo usa el arranque automático).
# Espera unos segundos a que el escritorio, la red y el puerto serial estén listos.
cd "$(dirname "$(readlink -f "$0")")" || exit 1
mkdir -p "$HOME/hmi_data"
sleep 6
exec /usr/bin/python3 hmi_main.py >> "$HOME/hmi_data/hmi.log" 2>&1
