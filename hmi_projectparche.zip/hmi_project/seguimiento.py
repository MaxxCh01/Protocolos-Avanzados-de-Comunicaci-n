"""
Seguimiento del satélite en segundo plano (el "radiotelescopio").

Un hilo propio (sin tocar Tkinter) hace, una vez elegido un satélite:
  1. calcula su posición (az/el/lat/lon) con SGP4;
  2. si está sobre el horizonte, manda los ángulos al Pico 2 (motor + servo);
  3. captura el espectro del RTL-SDR y busca la portadora;
  4. si la detecta, guarda una marca (lon, lat) para dibujar una X en el mapa.

Si NO hay satélite elegido, el hilo duerme y no hace nada.

Las pantallas del HMI solo LEEN el resultado con snapshot(); así, cuando
entras a cualquier pantalla el proceso ya viene corriendo.
"""
import threading
import time

from skyfield.api import wgs84

import config
import spectro_sdr


class SeguimientoSatelite:
    def __init__(self, ts, control_antena):
        self.ts = ts
        self.control = control_antena

        self._lock = threading.Lock()
        self._hay_seleccion = threading.Event()
        self._parar = threading.Event()

        self._gen = 0            # sube cada vez que cambia la selección (descarta ciclos viejos)
        self._etiqueta = None
        self._sat = None
        self._info = None
        self._estado = self._estado_vacio()

        self._t_cmd = 0.0        # solo lo toca el hilo de seguimiento
        self._ult_cmd = None

        self._hilo = threading.Thread(target=self._bucle, name="seguimiento", daemon=True)
        self._hilo.start()

    # ------------------------------------------------------------------
    @staticmethod
    def _estado_vacio():
        return {
            "activo": False, "etiqueta": None,
            "t_actualizacion": None,
            "az": 0.0, "el": 0.0, "dist": 0.0, "lat": 0.0, "lon": 0.0,
            "visible": False, "vel_radial": 0.0,
            "espectro": None, "espectro_id": 0,
            "detectado": False, "snr_db": 0.0,
            "n_detecciones": 0, "t_ultima_deteccion": None,
            "detecciones": [],            # [(lon, lat, t_unix, snr_db), ...]
            "modo_sdr": None,
            "cmd_az": None, "cmd_el": None,
            "pico_conectado": False,
            "error": None,
        }

    # ------------------------------------------------------------------
    # API pública (se llama desde el hilo de Tkinter)
    # ------------------------------------------------------------------
    def seleccionar(self, etiqueta, satelite, info):
        """Empieza (o sigue) el seguimiento de un satélite. Si es el mismo
        que ya se seguía, no se reinicia nada (se conservan las marcas)."""
        with self._lock:
            if self._etiqueta == etiqueta and self._sat is satelite:
                return
            self._gen += 1
            self._etiqueta = etiqueta
            self._sat = satelite
            self._info = info
            self._estado = self._estado_vacio()
            self._estado.update(activo=True, etiqueta=etiqueta)
            self._ult_cmd = None
            self._t_cmd = 0.0
        self._hay_seleccion.set()

    def deseleccionar(self):
        """Deja de seguir cualquier satélite: el hilo vuelve a no hacer nada."""
        with self._lock:
            self._gen += 1
            self._etiqueta = None
            self._sat = None
            self._info = None
            self._estado = self._estado_vacio()
        self._hay_seleccion.clear()

    def snapshot(self):
        """Copia del estado actual (segura para leer desde Tkinter)."""
        with self._lock:
            copia = dict(self._estado)
            copia["detecciones"] = list(self._estado["detecciones"])
            return copia

    def detener(self):
        """Para el hilo y libera el RTL-SDR. Llamar al cerrar el programa."""
        self._parar.set()
        self._hay_seleccion.set()
        try:
            spectro_sdr.cerrar_sdr()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Hilo de seguimiento
    # ------------------------------------------------------------------
    def _bucle(self):
        while not self._parar.is_set():
            if not self._hay_seleccion.wait(timeout=0.5):
                continue                      # nada elegido: no hace nada
            if self._parar.is_set():
                break
            with self._lock:
                gen, sat, info = self._gen, self._sat, self._info
            if sat is None:
                time.sleep(0.1)
                continue

            t0 = time.time()
            try:
                modo = self._ciclo(gen, sat, info)
            except Exception as e:
                print(f"[Seguimiento] Error en el ciclo: {e}")
                with self._lock:
                    if gen == self._gen:
                        self._estado["error"] = str(e)
                self._parar.wait(1.0)
                continue

            minimo = config.SEGUIMIENTO_PERIODO_MIN_S
            if modo == "sin_hardware":
                minimo = max(minimo, 0.6)     # sin SDR no hay prisa: no gastar CPU en ruido
            resto = minimo - (time.time() - t0)
            if resto > 0:
                self._parar.wait(resto)

    def _ciclo(self, gen, sat, info):
        t = self.ts.now()
        az, el, dist = self.control.calcular_az_el(sat, t)
        sub = wgs84.subpoint(sat.at(t))
        lat = float(sub.latitude.degrees)
        lon = float(sub.longitude.degrees)
        az, el, dist = float(az), float(el), float(dist)
        visible = el > 0
        vel = self.control.calcular_velocidad_radial(sat, t) if visible else 0.0

        cmd = self._apuntar_si_toca(az, el) if visible else None

        f = info["frecuencia_lrpt_hz"]
        res = spectro_sdr.analizar(
            frecuencia_central_hz=f,
            frecuencia_esperada_hz=f,
            hay_pase=visible,
            velocidad_radial_km_s=vel,
        )
        # Solo cuenta como detección si el satélite está sobre el horizonte.
        detectado = bool(visible and res["detectado"])

        with self._lock:
            if gen != self._gen:
                return res["modo"]           # cambió la selección mientras capturaba
            e = self._estado
            e.update(
                t_actualizacion=time.time(),
                az=az, el=el, dist=dist, lat=lat, lon=lon,
                visible=visible, vel_radial=float(vel),
                espectro=res, espectro_id=e["espectro_id"] + 1,
                detectado=detectado, snr_db=float(res["snr_db"]),
                modo_sdr=res["modo"],
                pico_conectado=bool(self.control.enlace_pico.conectado),
                error=None,
            )
            if cmd is not None:
                e["cmd_az"], e["cmd_el"] = cmd
            if detectado:
                e["n_detecciones"] += 1
                e["t_ultima_deteccion"] = time.time()
                self._agregar_marca(e, lon, lat, float(res["snr_db"]))
        return res["modo"]

    # ------------------------------------------------------------------
    def _apuntar_si_toca(self, az, el):
        """Manda ángulos nuevos al Pico, sin saturarlo: como máximo uno cada
        SEGUIMIENTO_INTERVALO_COMANDO_S y solo si la antena ya se desvió
        más de SEGUIMIENTO_UMBRAL_MOVIMIENTO_GRADOS."""
        ahora = time.time()
        if ahora - self._t_cmd < config.SEGUIMIENTO_INTERVALO_COMANDO_S:
            return None
        if self._ult_cmd is not None:
            d_az = abs((az - self._ult_cmd[0] + 180.0) % 360.0 - 180.0)
            d_el = abs(el - self._ult_cmd[1])
            if max(d_az, d_el) < config.SEGUIMIENTO_UMBRAL_MOVIMIENTO_GRADOS:
                return None
        self.control.apuntar_a(az, el)
        self._t_cmd = ahora
        self._ult_cmd = (az, el)
        return (az, el)

    @staticmethod
    def _agregar_marca(estado, lon, lat, snr_db):
        """Agrega una X al mapa, salvo que quede pegada a la anterior
        (así no se amontonan ~1000 X por pase)."""
        marcas = estado["detecciones"]
        if marcas:
            lon0, lat0 = marcas[-1][0], marcas[-1][1]
            d_lon = (lon - lon0 + 180.0) % 360.0 - 180.0
            if (d_lon ** 2 + (lat - lat0) ** 2) ** 0.5 < config.MARCA_SEPARACION_GRADOS:
                return
        marcas.append((lon, lat, time.time(), snr_db))
        if len(marcas) > config.MARCAS_MAX:
            del marcas[: len(marcas) - config.MARCAS_MAX]
