"""
Seguimiento del satélite en segundo plano (el "radiotelescopio").

Un hilo propio (sin tocar Tkinter) hace, una vez elegido un satélite:
  1. calcula su posición (az/el/lat/lon) con SGP4;
  2. si está sobre el horizonte, manda los ángulos al Pico 2 (motor + servo);
  3. captura el espectro del RTL-SDR y busca la portadora;
  4. mientras el satélite está sobre el horizonte, registra el RECORRIDO REAL
     del pase: un punto por captura, y si el SDR detectó la señal en ese
     punto, el punto lleva una X (se dibuja en el mapa y en la gráfica polar).

El recorrido de un pase se conserva (en memoria y en disco) cuando el
satélite se oculta, y se BORRA solo cuando el satélite vuelve a salir sobre
el horizonte (pase nuevo): ahí se vuelve a marcar desde cero.

Si NO hay satélite elegido, el hilo duerme y no hace nada.

Las pantallas del HMI solo LEEN el resultado con snapshot(); así, cuando
entras a cualquier pantalla el proceso ya viene corriendo.
"""
import json
import os
import threading
import time

from skyfield.api import wgs84

import config
import spectro_sdr

_DIR_DATOS = os.path.dirname(config.RUTA_CACHE_TLE)      # ~/hmi_data

# Cada punto del recorrido: (lon, lat, az, el, detectado 0|1, snr_db, t_unix)
_IDX_LON, _IDX_LAT, _IDX_AZ, _IDX_EL, _IDX_DET, _IDX_SNR, _IDX_T = range(7)


class SeguimientoSatelite:
    def __init__(self, ts, control_antena):
        self.ts = ts
        self.control = control_antena

        self._lock = threading.Lock()
        self._hay_seleccion = threading.Event()
        self._parar = threading.Event()

        self._gen = 0            # sube cada vez que cambia la selección (descarta ciclos viejos)
        self._etiqueta = None
        self._sat = None
        self._info = None
        self._estado = self._estado_vacio()

        self._t_cmd = 0.0        # solo lo toca el hilo de seguimiento
        self._ult_cmd = None
        self._visible_prev = None        # None = aún no se sabe (primer ciclo tras elegir)
        self._tt_ultimo_visible = None
        self._t_guardado = 0.0

        self._hilo = threading.Thread(target=self._bucle, name="seguimiento", daemon=True)
        self._hilo.start()

    # ------------------------------------------------------------------
    @staticmethod
    def _estado_vacio():
        return {
            "activo": False, "etiqueta": None,
            "t_actualizacion": None,
            "az": 0.0, "el": 0.0, "dist": 0.0, "lat": 0.0, "lon": 0.0,
            "visible": False, "vel_radial": 0.0,
            "espectro": None, "espectro_id": 0,
            "detectado": False, "snr_db": 0.0,
            # --- pase registrado (en curso, o el último si ya se ocultó) ---
            "n_ciclos_pase": 0,           # capturas con el satélite sobre el horizonte
            "n_detecciones": 0,           # de ésas, en cuántas se detectó la señal
            "pase_t_ini": None, "pase_t_fin": None,
            "recorrido": [],              # lista de puntos (ver _IDX_*)
            "modo_sdr": None,
            "cmd_az": None, "cmd_el": None,
            "pico_conectado": False,
            "error": None,
        }

    # ------------------------------------------------------------------
    # API pública (se llama desde el hilo de Tkinter)
    # ------------------------------------------------------------------
    def seleccionar(self, etiqueta, satelite, info):
        """Empieza (o sigue) el seguimiento de un satélite. Si es el mismo
        que ya se seguía, no se reinicia nada (se conserva el recorrido)."""
        with self._lock:
            if self._etiqueta == etiqueta and self._sat is satelite:
                return
            self._guardar_locked()               # deja guardado el recorrido del satélite anterior
            self._gen += 1
            self._etiqueta = etiqueta
            self._sat = satelite
            self._info = info
            self._estado = self._estado_vacio()
            self._estado.update(activo=True, etiqueta=etiqueta)
            self._ult_cmd = None
            self._t_cmd = 0.0
            self._visible_prev = None
            self._tt_ultimo_visible = None
        self._hay_seleccion.set()

    def deseleccionar(self):
        """Deja de seguir cualquier satélite: el hilo vuelve a no hacer nada."""
        with self._lock:
            self._guardar_locked()
            self._gen += 1
            self._etiqueta = None
            self._sat = None
            self._info = None
            self._estado = self._estado_vacio()
        self._hay_seleccion.clear()

    def snapshot(self, recorrido=False):
        """Copia del estado actual (segura para leer desde Tkinter).
        El recorrido (lista larga) solo se copia si se pide con recorrido=True."""
        with self._lock:
            copia = dict(self._estado)
            copia["recorrido"] = list(self._estado["recorrido"]) if recorrido else None
            return copia

    def detener(self):
        """Para el hilo, guarda el recorrido y libera el RTL-SDR."""
        self._parar.set()
        self._hay_seleccion.set()
        with self._lock:
            self._guardar_locked()
        try:
            spectro_sdr.cerrar_sdr()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Hilo de seguimiento
    # ------------------------------------------------------------------
    def _bucle(self):
        while not self._parar.is_set():
            if not self._hay_seleccion.wait(timeout=0.5):
                continue                      # nada elegido: no hace nada
            if self._parar.is_set():
                break
            with self._lock:
                gen, sat, info = self._gen, self._sat, self._info
            if sat is None:
                time.sleep(0.1)
                continue

            t0 = time.time()
            try:
                modo = self._ciclo(gen, sat, info)
            except Exception as e:
                print(f"[Seguimiento] Error en el ciclo: {e}")
                with self._lock:
                    if gen == self._gen:
                        self._estado["error"] = str(e)
                self._parar.wait(1.0)
                continue

            minimo = config.SEGUIMIENTO_PERIODO_MIN_S
            if modo == "sin_hardware":
                minimo = max(minimo, 0.6)     # sin SDR no hay prisa: no gastar CPU en ruido
            resto = minimo - (time.time() - t0)
            if resto > 0:
                self._parar.wait(resto)

    def _ciclo(self, gen, sat, info):
        t = self.ts.now()
        tt = float(t.tt)
        az, el, dist = self.control.calcular_az_el(sat, t)
        sub = wgs84.subpoint(sat.at(t))
        lat = float(sub.latitude.degrees)
        lon = float(sub.longitude.degrees)
        az, el, dist = float(az), float(el), float(dist)
        visible = el > 0
        vel = self.control.calcular_velocidad_radial(sat, t) if visible else 0.0

        # Primer ciclo tras elegir el satélite: recupera el recorrido guardado en disco
        primer_ciclo = self._visible_prev is None
        recuperado = self._leer_guardado(info, visible) if primer_ciclo else None

        # ¿empieza un pase nuevo? (estaba oculto, ahora sale, y estuvo oculto un buen rato)
        nuevo_pase = False
        if visible and self._visible_prev is False:
            if self._tt_ultimo_visible is None:
                nuevo_pase = True
            else:
                nuevo_pase = (tt - self._tt_ultimo_visible) * 86400.0 >= config.PASE_SEPARACION_MIN_S

        cmd = self._apuntar_si_toca(az, el) if visible else None

        f = info["frecuencia_lrpt_hz"]
        res = spectro_sdr.analizar(
            frecuencia_central_hz=f,
            frecuencia_esperada_hz=f,
            hay_pase=visible,
            velocidad_radial_km_s=vel,
        )
        # Solo cuenta como detección si el satélite está sobre el horizonte.
        detectado = bool(visible and res["detectado"])

        with self._lock:
            if gen != self._gen:
                return res["modo"]           # cambió la selección mientras capturaba
            e = self._estado

            if primer_ciclo and recuperado:
                self._poner_recorrido(e, recuperado)
            if nuevo_pase:
                # El satélite volvió a pasar: se borra el pase anterior y se marca desde cero.
                self._poner_recorrido(e, [])

            e.update(
                t_actualizacion=time.time(),
                az=az, el=el, dist=dist, lat=lat, lon=lon,
                visible=visible, vel_radial=float(vel),
                espectro=res, espectro_id=e["espectro_id"] + 1,
                detectado=detectado, snr_db=float(res["snr_db"]),
                modo_sdr=res["modo"],
                pico_conectado=bool(self.control.enlace_pico.conectado),
                error=None,
            )
            if cmd is not None:
                e["cmd_az"], e["cmd_el"] = cmd

            if visible:
                self._agregar_punto(e, (lon, lat, az, el, 1 if detectado else 0,
                                        float(res["snr_db"]), time.time()))
                self._tt_ultimo_visible = tt
                if time.time() - self._t_guardado >= config.RECORRIDO_GUARDADO_CADA_S:
                    self._guardar_locked()
            elif self._visible_prev is True:
                self._guardar_locked()       # terminó el pase: queda guardado hasta el próximo
            self._visible_prev = visible
        return res["modo"]

    # ------------------------------------------------------------------
    # Recorrido del pase
    # ------------------------------------------------------------------
    @staticmethod
    def _poner_recorrido(estado, puntos):
        estado["recorrido"] = list(puntos)
        estado["n_ciclos_pase"] = len(puntos)
        estado["n_detecciones"] = sum(1 for p in puntos if p[_IDX_DET])
        estado["pase_t_ini"] = puntos[0][_IDX_T] if puntos else None
        estado["pase_t_fin"] = puntos[-1][_IDX_T] if puntos else None

    @staticmethod
    def _agregar_punto(estado, punto):
        rec = estado["recorrido"]
        rec.append(punto)
        if len(rec) > config.RECORRIDO_MAX_PUNTOS:
            del rec[: len(rec) - config.RECORRIDO_MAX_PUNTOS]
        estado["n_ciclos_pase"] = len(rec)
        if punto[_IDX_DET]:
            estado["n_detecciones"] += 1
        estado["pase_t_ini"] = rec[0][_IDX_T]
        estado["pase_t_fin"] = punto[_IDX_T]

    def _ruta_guardado(self, info):
        nombre = "".join(c if c.isalnum() else "_" for c in info["clave"])
        return os.path.join(_DIR_DATOS, f"recorrido_{nombre}.json")

    def _guardar_locked(self):
        """Guarda el recorrido del satélite actual en disco (escritura atómica).
        Se llama con self._lock tomado."""
        rec = self._estado["recorrido"]
        if self._info is None or not rec:
            return
        try:
            os.makedirs(_DIR_DATOS, exist_ok=True)
            ruta = self._ruta_guardado(self._info)
            tmp = ruta + ".tmp"
            datos = {
                "satelite": self._etiqueta,
                "recorrido": [[round(p[0], 4), round(p[1], 4), round(p[2], 2), round(p[3], 2),
                               int(p[4]), round(p[5], 1), round(p[6], 1)] for p in rec],
            }
            with open(tmp, "w") as fh:
                json.dump(datos, fh)
            os.replace(tmp, ruta)
            self._t_guardado = time.time()
        except Exception as e:
            print(f"[Seguimiento] No se pudo guardar el recorrido: {e}")

    def _leer_guardado(self, info, visible_ahora):
        """Lee el recorrido guardado de este satélite. Si ahora mismo el
        satélite está a mitad de un pase, solo se acepta lo guardado hace
        poco (es del mismo pase); si no, es el del último pase y se conserva
        hasta que el satélite vuelva a salir."""
        try:
            with open(self._ruta_guardado(info)) as fh:
                datos = json.load(fh)
            puntos = [tuple(p) for p in datos.get("recorrido", []) if len(p) == 7]
        except Exception:
            return []
        if puntos and visible_ahora:
            if time.time() - puntos[-1][_IDX_T] > config.RECORRIDO_EDAD_MAX_MID_PASE_S:
                return []
        return puntos

    # ------------------------------------------------------------------
    def _apuntar_si_toca(self, az, el):
        """Manda ángulos nuevos al Pico, sin saturarlo: como máximo uno cada
        SEGUIMIENTO_INTERVALO_COMANDO_S y solo si la antena ya se desvió
        más de SEGUIMIENTO_UMBRAL_MOVIMIENTO_GRADOS."""
        ahora = time.time()
        if ahora - self._t_cmd < config.SEGUIMIENTO_INTERVALO_COMANDO_S:
            return None
        if self._ult_cmd is not None:
            d_az = abs((az - self._ult_cmd[0] + 180.0) % 360.0 - 180.0)
            d_el = abs(el - self._ult_cmd[1])
            if max(d_az, d_el) < config.SEGUIMIENTO_UMBRAL_MOVIMIENTO_GRADOS:
                return None
        self.control.apuntar_a(az, el)
        self._t_cmd = ahora
        self._ult_cmd = (az, el)
        return (az, el)
